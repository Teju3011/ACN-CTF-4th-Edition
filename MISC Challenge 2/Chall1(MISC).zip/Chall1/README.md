This is a simple git challenge But not this simple# A more powerful method: search all commits for the string CTF
git grep CTF # A more powerful method: search all commits for the string CTF
git grep CTF 
